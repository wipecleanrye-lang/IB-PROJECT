# SignalBridge AI Consulting Website

This is a static, GitHub Pages-ready website for an IB Business Management marketing plan project. It presents an AI consulting firm called **SignalBridge AI Consulting** and covers the required rubric areas:

- Business concept and value proposition
- Target market and customer profile
- Market research with cited sources
- Competitor analysis
- SWOT analysis
- Seven Ps marketing mix
- Financial forecast and start-up costs
- Risk management
- Ethics and sustainability
- International expansion into the United Kingdom
- Promotion examples
- Rubric coverage checklist

## How to run locally

Open `index.html` in a browser. No build step is required.

## How to publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload these files:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `assets/logo.svg`
   - `assets/og-card.svg`
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/root` folder.
6. Save, then wait for GitHub to publish the site.

## Main data sources used

- Stanford HAI, 2025 AI Index Report: https://hai.stanford.edu/ai-index/2025-ai-index-report
- McKinsey, The State of AI in 2025: https://www.mckinsey.com/capabilities/quantumblack/our-insights/the-state-of-ai
- U.S. Chamber of Commerce, Small Business AI Adoption: https://www.uschamber.com/technology/empowering-small-business-the-impact-of-technology-on-u-s-small-business
- Gartner, Worldwide AI Spending 2025: https://www.gartner.com/en/newsroom/press-releases/2025-09-17-gartner-says-worldwide-ai-spending-will-total-1-point-5-trillion-in-2025
- Gartner, Generative AI Spending 2025: https://www.gartner.com/en/newsroom/press-releases/2025-03-31-gartner-forecasts-worldwide-genai-spending-to-reach-644-billion-in-2025
- Gartner, AI Services Market Forecast: https://www.gartner.com/en/documents/7004398
- YouGov, UK SME AI Adoption: https://yougov.com/en-gb/articles/52730-we-polled-uk-sme-leaders-about-ai-adoption-heres-what-they-said
- UK ICO, AI and Data Protection Guidance: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/guidance-on-ai-and-data-protection/
- GOV.UK, AI Opportunities Action Plan: https://www.gov.uk/government/publications/ai-opportunities-action-plan/ai-opportunities-action-plan

## Suggested edits before submitting

- Replace the business name if you want your own brand.
- Add your name/class period if required.
- Adjust the financial forecast if your teacher expects simpler math.
- Add screenshots or mockups in Canva if you want more visual product examples.
- Practice the pitch using the order of the website sections.
