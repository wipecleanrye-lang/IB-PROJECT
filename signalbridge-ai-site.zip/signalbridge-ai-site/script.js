const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');

if (navToggle && navLinks) {
  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });

  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });
}

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealItems.forEach((item) => observer.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add('visible'));
}

const tabShell = document.querySelector('[data-tabs]');
if (tabShell) {
  const tabs = [...tabShell.querySelectorAll('[role="tab"]')];
  const panels = [...tabShell.querySelectorAll('[role="tabpanel"]')];

  const activateTab = (tab) => {
    tabs.forEach((item) => item.setAttribute('aria-selected', String(item === tab)));
    panels.forEach((panel) => {
      const shouldShow = panel.id === tab.getAttribute('aria-controls');
      panel.hidden = !shouldShow;
      panel.classList.toggle('active', shouldShow);
    });
    tab.focus();
  };

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateTab(tab));
    tab.addEventListener('keydown', (event) => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      let nextIndex = index;
      if (event.key === 'ArrowRight') nextIndex = (index + 1) % tabs.length;
      if (event.key === 'ArrowLeft') nextIndex = (index - 1 + tabs.length) % tabs.length;
      if (event.key === 'Home') nextIndex = 0;
      if (event.key === 'End') nextIndex = tabs.length - 1;
      activateTab(tabs[nextIndex]);
    });
  });
}

const copyButtons = document.querySelectorAll('[data-copy]');
copyButtons.forEach((button) => {
  button.addEventListener('click', async () => {
    const originalText = button.textContent;
    try {
      await navigator.clipboard.writeText(button.dataset.copy || '');
      button.textContent = 'Copied';
    } catch (error) {
      button.textContent = 'Select text';
    }
    window.setTimeout(() => {
      button.textContent = originalText;
    }, 1600);
  });
});

const forecastForm = document.querySelector('#forecast-form');
const forecastOutput = document.querySelector('#forecast-output');

const prices = {
  audits: 1750,
  sprints: 5500,
  workshops: 2400,
  governance: 3800,
  retainers: 23100 // average annualized value per client based on 7 months at $3,300
};

function currency(number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(number);
}

function updateForecast() {
  if (!forecastForm || !forecastOutput) return;
  const values = Object.keys(prices).reduce((total, id) => {
    const input = document.querySelector(`#${id}`);
    const quantity = Number(input?.value || 0);
    return total + quantity * prices[id];
  }, 0);
  forecastOutput.value = currency(values);
  forecastOutput.textContent = currency(values);
}

if (forecastForm) {
  forecastForm.addEventListener('input', updateForecast);
  updateForecast();
}

const printButton = document.querySelector('#print-page');
if (printButton) {
  printButton.addEventListener('click', () => window.print());
}
